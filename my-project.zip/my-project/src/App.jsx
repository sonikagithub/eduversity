import { useState } from 'react'

import './App.css'
import HomeRoutes from './components/Routes/HomeRoutes'

function App() {


  return (
    <>
     <HomeRoutes/>
    </>
  )
}

export default App
